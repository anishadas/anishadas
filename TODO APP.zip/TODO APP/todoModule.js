var TodoListApp=(function () {
    var addTaskInput = document.getElementById("add");
    var taskList = document.getElementById("list");
    var taskCounter = document.getElementById("task-counter");
    var totalTask = document.getElementById("total-tasks");
    let tasks = [];
    var a = 0;
    //async function fetchTodos(){

    // ......USING PROMISE FETCH API............
    // fetch('https://jsonplaceholder.typicode.com/todos')
    //     .then(function(response) {
    //         console.log(response);
    //         return response.json();
    //     }).then(function(data){
    //         tasks=data.slice(0,10);
    //         renderList();
    //     })
    //     .catch(function(error){
    //         console.log("error",error);
    //     })


    // ......USING ASYNC FUNCTION WITH FETCH API.......
    // try{
    //     const response= await fetch("https://jsonplaceholder.typicode.com/todos");
    //     const data=await response.json();
    //     tasks=data.slice(0,10);
    //     renderList();
    // }
    // catch(error){
    //    console.log(error);
    // }

    //}
    function addTaskList(task) {
        if (task) {
            tasks.push(task);
            renderList(tasks);
            showNotification("task added successfully");
            return;
        }
        showNotification("task not added");
    }
    function deleteTaskList(taskId) {
        const newTasks = tasks.filter(function (task) {
            return task.id !== Number(taskId);
        })
        tasks = newTasks;
        showNotification("task deleted successfully");
        renderList(tasks);
    }

    function taskToDOM(task) {
        const li = document.createElement('li');
        li.innerHTML =
            `<input type="checkbox" id="${task.id}" ${task.completed ? 'checked' : ''} class="custom-checkbox">
        <label for="${task.id}">${task.title}</label>
        <img src="https://img.icons8.com/material-outlined/24/undefined/trash--v1.png" class="delete" data-id="${task.id}" />`;
        taskList.append(li);
    }
    function renderList() {
        taskList.innerHTML = "";
        for (let i = 0; i < tasks.length; i++) {
            taskToDOM(tasks[i]);
        }
        taskCounter.innerHTML = tasks.length;
    }
    function markTaskAsComplete(taskId) {
        const task1 = tasks.filter(function (task) {
            return task.id === Number(taskId);
        });
        if (task1.length > 0) {
            task1[0].completed = !task1[0].completed;
            renderList(tasks);
            showNotification("task status toggled");
            return;
        }
        showNotification("not updated status");
    }
    function showNotification(text) {
        alert(text);
    }

    function handleClickEvents(e) {
        const target = e.target;
        console.log(target);
        if (target.className === 'delete') {
            const taskId = target.dataset.id;
            deleteTaskList(taskId);
            return;
        }
        else if (target.className === 'custom-checkbox') {
            const taskId = target.id;
            markTaskAsComplete(taskId);
            return;
        }
    }
    function initializeApp() {
        //fetchTodos();
        document.addEventListener('click', handleClickEvents);
        addTaskInput.addEventListener('keyup', handleInput);
    }

    function handleInput(e) {
        if (e.key == 'Enter') {
            const text = e.target.value;
            console.log(text);
            if (!text) {
                showNotification("input text cannot be empty");
                return;
            }
            const task = {
                title: text,
                id: Date.now(),
                completed: false
            };
            e.target.value = '';
            addTaskList(task);
        }
    }
   return {
       initialize: initializeApp,
       a:a
   }
})();
